﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebProgramlamaProje.Models
{
    public class OnerileriniYaz
    {
        public string ad { get; set; }
        public string soyad { get; set; }
        public string email { get; set; }
        public int numara { get; set; }
        public string Fikir { get; set; }
        public string Oneriniz { get; set; }
    }
}
