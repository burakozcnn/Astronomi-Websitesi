﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebProgramlamaProje.Models
{
    public class Galaksiler
    {
        public class Yildizlar
        {
            public int id { get; set; }
            public string ad { get; set; }
            public string aciklama { get; set; }
            public string resimYeri { get; set; }
            public int kesfedildigiTarih { get; set; }
            public string guneseUzakligi { get; set; }
            public string TahminiYas { get; set; }
            public string yuzOlcumu { get; set; }

        }
        public class Gezegenler
        {
            public int id { get; set; }
            public string ad { get; set; }
            public string aciklama { get; set; }
            public string resimYeri { get; set; }
            public int kesfedildigiTarih { get; set; }
            public string guneseUzakligi { get; set; }
            public string TahminiYas { get; set; }
            public string yuzOlcumu { get; set; }
        }
    }
}
