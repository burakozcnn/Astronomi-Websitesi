﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProgramlamaProje.Models;

namespace WebProgramlamaProje.Controllers
{
    public class GuncelHaberlerController : Controller
    {
        public IActionResult GuncelHaberler()
        {

            List<GuncelHaberler> Guncel = new List<GuncelHaberler>();
            Guncel.Add(new GuncelHaberler() { id = 1, tittle = "Marsta Su Bulundu", description = "Amerikan Uzay ve Havacılık Dairesi (NASA), geçtiğimiz aylarda Mars'ta Perseverance gezgini tarafından toplanan ilk örneklerin Kızıl Gezegen’de suyun bulunduğunu gösterdiğini duyurmuştu. ABD'de yapılan yeni bir araştırma ise Kızıl Gezegen'deki suyun.", image = "/images/mars.jpg"});
            Guncel.Add(new GuncelHaberler() { id = 2, tittle = "Perseverance'ın Yılı", description = "UPI’nin haberine göre, Mars’ta geçirdiği 1 yıl içerisinde kendi sistemlerini ve Ingenuity helikopterinin sistemlerini deneyen Perseverance, ayrıca gezegenin kuzey bölgesindeki Jezero Krateri'nin zemininde 6 kaya örneği de topladı.", image = "/images/haber1.webp" });
            Guncel.Add(new GuncelHaberler() { id = 3, tittle = "Üçüz Galaksiler", description = "Üç galaksi birleşimi olarak da bilinen bu olay, üç galaksinin birbirini gittikçe daha da yakına çekerek karşılıklı yerçekimi kuvvetleriyle parçalaması sonucu meydana geliyor. Bu durum görenleri adeta şaşkına uğrattı. ", image = "/images/haber2.webp", });
            Guncel.Add(new GuncelHaberler() { id = 4, tittle = "Gizemli nesne", description = "Neptün - ötesi nesne  2021 XD7 diye tanımlandı ve Richard Boyle tarafından 3 Aralık'ta Vatikan İleri Teknoloji Teleskobu'yla tespit edildi. Bu durum görenleri adeta şaşkına uğrattı. ", image = " /images/haber3.webp" });
            Guncel.Add(new GuncelHaberler() { id = 5, tittle = "Mars Simülasyonu", description = "Tesla ve SpaceX CEO'su Elon Musk, 2030'dan itibaren başlatılması beklenen Mars gezegenine yönelik insanlı görevin simüle edildiği bir animasyon paylaştı. Musk, videoya yer verdiği Twitter paylaşımında gösterdi.", image = "/images/haber4.webp" });
            Guncel.Add(new GuncelHaberler() { id = 6, tittle = "SpaceX Görevi", description = "Independent Türkçe'nin haberine göre; Isaacman'a emekli ABD Hava Kuvvetleri savaş pilotu Scott Poteet, SpaceX operasyon mühendisi Sarah Gillis ve gemide sağlık görevlisi rolünü üstelenecek mühendis Anna Menon katılacak. Bu isimlerden ikisi ilk ticari uzay yürüyüşüne çıkacak. ", image = "/images/haber5.jpg" });
            Guncel.Add(new GuncelHaberler() { id = 7, tittle = "Kaotik Görüntü", description = "Hem Dünya'da hem de Mars'ta görülebilen ve yüzeydeki tozları birbirine katan hortumlara toz şeytanı ismi veriliyor. Bunlar, diğer hortumlardan farklı olarak bulutlardan aşağı doğru değil, yerden yukarı doğru oluşuyor. Independent Türkçe'nin haberine göre; uzay ajansı yoktur.", image = "/images/haber6.webp" });
            Guncel.Add(new GuncelHaberler() { id = 8, tittle = "2 yeni Güneş görevi", description = "NASA’dan dün yapılan açıklamada, Güneş’in dinamiklerini, Güneş-Dünya bağlantısını ve sürekli değişen uzay ortamını anlamaya yardımcı olmasına yönelik MUSE (Multi-slit Solar Explorer) ve HelioSwarm olarak adlandırılan iki yeni Güneş görevi seçtiğini duyurdu. ", image = "/images/haber7.webp" });

            ViewBag.GuncelHaberler = Guncel.ToList();
            return View();
        }

        public IActionResult GuncelHaberlerDetay(int? id)
        {

            List<GuncelHaberler> Guncel = new List<GuncelHaberler>();
            Guncel.Add(new GuncelHaberler() { id = 1, tittle = "Marsta Su Bulundu", description = "Amerikan Uzay ve Havacılık Dairesi (NASA), geçtiğimiz aylarda Mars'ta Perseverance gezgini tarafından toplanan ilk örneklerin Kızıl Gezegen’de suyun bulunduğunu gösterdiğini duyurmuştu. ABD'de yapılan yeni bir araştırma ise Kızıl Gezegen'deki suyun.", image = "/images/mars.jpg" });
            Guncel.Add(new GuncelHaberler() { id = 2, tittle = "Perseverance'ın Yılı", description = "UPI’nin haberine göre, Mars’ta geçirdiği 1 yıl içerisinde kendi sistemlerini ve Ingenuity helikopterinin sistemlerini deneyen Perseverance, ayrıca gezegenin kuzey bölgesindeki Jezero Krateri'nin zemininde 6 kaya örneği de topladı.", image = "/images/haber1.webp" });
            Guncel.Add(new GuncelHaberler() { id = 3, tittle = "Üçüz Galaksiler", description = "Üç galaksi birleşimi olarak da bilinen bu olay, üç galaksinin birbirini gittikçe daha da yakına çekerek karşılıklı yerçekimi kuvvetleriyle parçalaması sonucu meydana geliyor. Bu durum görenleri adeta şaşkına uğrattı. ", image = "/images/haber2.webp", });
            Guncel.Add(new GuncelHaberler() { id = 4, tittle = "Gizemli nesne", description = "Neptün - ötesi nesne  2021 XD7 diye tanımlandı ve Richard Boyle tarafından 3 Aralık'ta Vatikan İleri Teknoloji Teleskobu'yla tespit edildi. Bu durum görenleri adeta şaşkına uğrattı. ", image = " /images/haber3.webp" });
            Guncel.Add(new GuncelHaberler() { id = 5, tittle = "Mars Simülasyonu", description = "Tesla ve SpaceX CEO'su Elon Musk, 2030'dan itibaren başlatılması beklenen Mars gezegenine yönelik insanlı görevin simüle edildiği bir animasyon paylaştı. Musk, videoya yer verdiği Twitter paylaşımında gösterdi.", image = "/images/haber4.webp" });
            Guncel.Add(new GuncelHaberler() { id = 6, tittle = "SpaceX Görevi", description = "Independent Türkçe'nin haberine göre; Isaacman'a emekli ABD Hava Kuvvetleri savaş pilotu Scott Poteet, SpaceX operasyon mühendisi Sarah Gillis ve gemide sağlık görevlisi rolünü üstelenecek mühendis Anna Menon katılacak. Bu isimlerden ikisi ilk ticari uzay yürüyüşüne çıkacak. ", image = "/images/haber5.jpg" });
            Guncel.Add(new GuncelHaberler() { id = 7, tittle = "Kaotik Görüntü", description = "Hem Dünya'da hem de Mars'ta görülebilen ve yüzeydeki tozları birbirine katan hortumlara toz şeytanı ismi veriliyor. Bunlar, diğer hortumlardan farklı olarak bulutlardan aşağı doğru değil, yerden yukarı doğru oluşuyor. Independent Türkçe'nin haberine göre; uzay ajansı yoktur.", image = "/images/haber6.webp" });
            Guncel.Add(new GuncelHaberler() { id = 8, tittle = "2 yeni Güneş görevi", description = "NASA’dan dün yapılan açıklamada, Güneş’in dinamiklerini, Güneş-Dünya bağlantısını ve sürekli değişen uzay ortamını anlamaya yardımcı olmasına yönelik MUSE (Multi-slit Solar Explorer) ve HelioSwarm olarak adlandırılan iki yeni Güneş görevi seçtiğini duyurdu. ", image = "/images/haber7.webp" });

            return View(Guncel.FirstOrDefault(x => x.id == id));
        }
    }
}
