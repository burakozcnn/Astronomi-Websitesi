﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProgramlamaProje.Models;

namespace WebProgramlamaProje.Controllers
{
    public class HomeController : Controller
    {

        private static OnerileriniYaz _gonder;
        public IActionResult AnaSayfa()
        {
            ViewBag.text1 = "Gezegenler";
            ViewData["İndexText"] = "Keşfet...";
            TempData["İndexText2"] = "Büyüleyici";
            return View();
        }

        public IActionResult Hakkimizda()
        {
            ViewBag.content1 = "Uzun yıllardır Astronomi ile ilgileniyorum ve bunun üstüne araştırmalar yapıp yazılar yazıyoruz. Şimdiye kadar yazdığım yazıları ve yazacağım yeni yazıları okuyucularla paylaşıp elimden geldiğince yararlı olmak istiyorum. Amacım Astronomi ile ilgili bilgi edinmek isteyen kişilerin yararlanabileceği içerikler oluşturmak ve bu içerikleri okuyucuların beğenisine sunmak.";
            ViewData["content2"] = "Gökbilim bağlamında bilim ve teknoloji eğitimi ve araştırmaları alanında öncü niteliği ile bilgi ve becerilerini insanlık ve ülke yararına kullanabilen, paylaşabilen ve evrensel normları özümsemiş yenilikçi anlayışa sahip bir bölüm olmaktır";
            TempData["content3"] = "Hizmetleri 2002'li yıllarda başlayan, tecrübeli NASA ve Gezegen gruplarıyla yenilenerek güçlenen grubumuz yüzlerce projeye imza atan ve aynı zamanda bu projelerin uygulamasını da üstlenen ve nitelikli yapılar üreten bir firma olarak 2020 yılında yeniden yapılanmıştır.";
            return View();
        }


        public IActionResult İletisim()
        {
            return View();
        }
        [HttpPost]
        public IActionResult İletisim(OnerileriniYaz Mesaj_gonder)
        {
            _gonder = Mesaj_gonder;
            return RedirectToAction("İletisim2");
        }
        public IActionResult İletisim2()
        {
            TempData["Onerileriniz"] = "Soru ve Önerileriniz Bize Ulaşmıştır. En Kısa Sürede Geri Dönüş Yapılacaktır...";
            return View(_gonder);
        }
    }
}

